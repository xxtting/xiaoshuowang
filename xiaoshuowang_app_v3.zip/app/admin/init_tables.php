<?php
/**
 * 初始化数据库表
 * 用于创建系统设置、AI设置等必要的表
 */

session_start();

// 检查管理员登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.html');
    exit;
}

// 引入数据库配置
$dbConfigFile = __DIR__ . '/../backend/config/database.php';
if (!file_exists($dbConfigFile)) {
    die("错误：数据库配置文件不存在");
}

require_once $dbConfigFile;

// 检查常量
if (!defined('DB_HOST') || !defined('DB_NAME') || !defined('DB_USER') || !defined('DB_PASS')) {
    die("错误：数据库配置不完整");
}

// 数据库连接
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

// 需要创建的表
$tables = [
    'system_settings' => "
        CREATE TABLE IF NOT EXISTS `system_settings` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `setting_key` varchar(100) NOT NULL COMMENT '设置键',
          `setting_value` text COMMENT '设置值',
          `setting_type` varchar(50) DEFAULT 'text' COMMENT '设置类型',
          `description` varchar(255) DEFAULT NULL COMMENT '设置描述',
          `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
          `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (`id`),
          UNIQUE KEY `uk_key` (`setting_key`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';
    ",
    'ai_settings' => "
        CREATE TABLE IF NOT EXISTS `ai_settings` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `setting_key` varchar(100) NOT NULL COMMENT '设置键',
          `setting_value` text COMMENT '设置值',
          `description` varchar(255) DEFAULT NULL COMMENT '设置描述',
          `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
          `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (`id`),
          UNIQUE KEY `uk_key` (`setting_key`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='AI设置表';
    ",
    'sys_log' => "
        CREATE TABLE IF NOT EXISTS `sys_log` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
          `action` varchar(100) NOT NULL COMMENT '操作类型',
          `description` varchar(500) DEFAULT NULL COMMENT '操作描述',
          `ip` varchar(50) DEFAULT NULL COMMENT 'IP地址',
          `user_agent` text COMMENT '用户代理',
          `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY (`id`),
          KEY `idx_user_id` (`user_id`),
          KEY `idx_action` (`action`),
          KEY `idx_created_at` (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统操作日志表';
    ",
    'user_favorite' => "
        CREATE TABLE IF NOT EXISTS `user_favorite` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `user_id` int(11) NOT NULL COMMENT '用户ID',
          `novel_id` int(11) NOT NULL COMMENT '小说ID',
          `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY (`id`),
          UNIQUE KEY `uk_user_novel` (`user_id`, `novel_id`),
          KEY `idx_user_id` (`user_id`),
          KEY `idx_novel_id` (`novel_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户收藏表';
    "
];

// 执行结果
$results = [];

foreach ($tables as $tableName => $sql) {
    try {
        $pdo->exec($sql);
        $results[$tableName] = ['status' => 'success', 'message' => '创建成功'];
    } catch (PDOException $e) {
        $results[$tableName] = ['status' => 'error', 'message' => $e->getMessage()];
    }
}

// 输出结果
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>初始化数据库表</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 28px;
            font-weight: 600;
        }
        
        .content {
            padding: 30px;
        }
        
        .result-list {
            list-style: none;
        }
        
        .result-item {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
        }
        
        .result-item:last-child {
            border-bottom: none;
        }
        
        .status-icon {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 16px;
        }
        
        .status-success {
            background: #d4edda;
            color: #155724;
        }
        
        .status-error {
            background: #f8d7da;
            color: #721c24;
        }
        
        .table-name {
            flex: 1;
            font-weight: 500;
            color: #495057;
        }
        
        .message {
            color: #6c757d;
            font-size: 14px;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: transform 0.3s;
            margin-top: 20px;
        }
        
        .btn:hover {
            transform: translateY(-2px);
        }
        
        .actions {
            text-align: center;
            padding-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🗄️ 数据库表初始化</h1>
        </div>
        
        <div class="content">
            <ul class="result-list">
                <?php foreach ($results as $tableName => $result): ?>
                <li class="result-item">
                    <div class="status-icon <?php echo $result['status'] === 'success' ? 'status-success' : 'status-error'; ?>">
                        <?php echo $result['status'] === 'success' ? '✓' : '✗'; ?>
                    </div>
                    <div class="table-name"><?php echo $tableName; ?></div>
                    <div class="message"><?php echo $result['message']; ?></div>
                </li>
                <?php endforeach; ?>
            </ul>
            
            <div class="actions">
                <a href="dashboard.html" class="btn">返回后台</a>
            </div>
        </div>
    </div>
</body>
</html>
