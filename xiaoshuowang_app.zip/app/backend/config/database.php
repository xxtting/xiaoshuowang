<?php
/**
 * 数据库配置文件
 * 实际配置文件
 */

// 定义数据库连接常量
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'xiaoshuowang');
define('DB_USER', 'root');
define('DB_PASS', 'your_password_here');
define('DB_CHARSET', 'utf8mb4');
define('DB_PREFIX', '');

// 返回配置数组（兼容其他代码）
return [
    'host' => DB_HOST,
    'port' => DB_PORT,
    'database' => DB_NAME,
    'username' => DB_USER,
    'password' => DB_PASS,
    'charset' => DB_CHARSET,
    'prefix' => DB_PREFIX,
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ],
];
